<template>
<div>
    <h1>
        Article
    </h1>
</div>
</template>
