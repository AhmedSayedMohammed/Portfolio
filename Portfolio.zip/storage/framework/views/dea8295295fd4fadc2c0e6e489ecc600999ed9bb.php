<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <script> Window.Laravel={ csefToken: "<?php echo e(csrf_token()); ?>"} </script>
        <title>Laravel</title>

        <!-- Fonts -->
        <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet"/>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #dae3e7;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>

    </head>
    <body>

<div class="container-fluid clearfix bg-light">
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <a class="navbar-brand" href="#">Navbar</a>

        <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
          <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
              <a class="nav-link disabled" href="#">Disabled</a>
            </li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>

      
      <div class="row p-3">
        <div class="col-9 col-xs- col-sm- col-md- col-lg- col float-left items position-relative  align-self-center">

        <div class="float-left">
        <img src="/Images/CVPic.jpg" style=" height: 200px; width= 200px;" class="rounded-circle p-1 border border-dark"  alt="profile photo">
        </div>

        <div class="float-left text-center p-4">
            <h1>Ahmed Sayed</h1>
            <h3>Software Engineer</h3>
        </div>

        </div>

          <div class="col-xs- col-sm- col-md- col-lg- align-self-center ">
          <a href="#" class="btn btn-success padding-10 btn=lg"> <h3> Contact Me 
         <i class="fab fa-angellist"></i></h3>
           </a>
          </div>
      </div>
     
 </div>

  <div class="m-5 bg-light">
        <h2 class="p-3">About me</h2>
              <p class="p-2  mb-2">
                 I'm a software developer with a bachelor degree in computer science from faculty of computers and information june 2018 
              </p>
          </div>


          <div id="app">
      <div class="container">
      <articles></articles>
      </div>
      </div>
      <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>  

    <script src="/js/app.js"></script>
</html>
<?php /**PATH C:\Users\ahmed\Desktop\Laravel Project\Portfolio\Portfolio\resources\views/welcome.blade.php ENDPATH**/ ?>